.menu-section-chess i:before {

    font-family: Font Awesome 5 Free;

    content: "\f439";

}

.menu-section-item-chess:before {

    content: "\f43c" !important;

}
}
.icontainer {
  position: absolute;
  overflow: hidden;
  width: 100%;
  padding-top: 55.5%; 
}
.responsive-iframe {
  position: absolute;
  top: 0;
  left: 0;
  bottom: 0;
  right: 0;
  width: 100%;
  height: 100%;
}
